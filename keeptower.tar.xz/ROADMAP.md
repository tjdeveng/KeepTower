# KeepTower Development Roadmap

This document outlines the planned features and improvements for KeepTower, organized by release milestones.

## Current Version: v0.2.8-beta (In Development)

✅ Core vault management with AES-256-GCM encryption
✅ Reed-Solomon forward error correction (5-50% redundancy)
✅ Automatic backup system
✅ Password strength validation
✅ FEC preferences with per-vault settings
✅ GTK4/libadwaita UI with dark mode support
✅ **NEW: Configurable clipboard auto-clear (5-300 seconds)**
✅ **NEW: Auto-lock after inactivity (60-3600 seconds)**
✅ **NEW: Password history tracking (UI ready, backend pending)**
✅ **NEW: Modern sidebar preferences dialog (GNOME HIG compliant)**
✅ **NEW: Activity monitoring for security features**
✅ **NEW: Session timeout with re-authentication**

---

## Near-term (v0.2.x - Security Quick Wins) - IN PROGRESS

### Security Enhancements
- [x] Clipboard auto-clear after paste (configurable 5-300s delay)
- [x] Auto-lock after configurable inactivity timeout (60-3600s)
- [x] Session timeout with re-authentication (integrated with auto-lock)
- [x] Password history tracking per account (prevents reuse) - **Completed**
- [x] Hardware-based two-factor authentication (YubiKey challenge-response) - **v0.2.0+**
- [ ] Authenticator app support (TOTP/HOTP code generation for services)
- [ ] Biometric unlock support (fingerprint via polkit) - *requires hardware access*

### Usability Improvements
- [x] Import functionality (KeePass XML, 1Password 1PIF, CSV formats) - **v0.2.5-beta**
- [x] Export functionality with security warnings - **v0.2.5-beta**
- [x] Enhanced password generator with customizable rules - **Completed**
- [x] Tags system for organizing accounts - **v0.2.6-beta**
- [x] Tag-based filtering in account list - **v0.2.6-beta**
- [x] Favorites/starred accounts for quick access - **v0.2.6-beta**
- [x] Advanced search (fuzzy search, filters by field) - **v0.2.7-beta**
- [x] Undo/redo support for vault operations - **v0.2.7-beta**
- [x] Drag-and-drop account reordering - **v0.2.7-beta**

### Data Features
- [ ] Custom fields per account (key-value pairs)
- [ ] File attachments (encrypted documents, notes, images)
- [ ] Multi-vault support (open/switch between multiple vaults)
- [ ] Vault merge capabilities
- [x] **Account groups/folders for organization (Backend complete - v0.2.8-beta)**
  - [x] Multi-group membership support
  - [x] System "Favorites" group (auto-created)
  - [x] Create, delete, add/remove accounts from groups
  - [x] UUID-based group identification
  - [x] Comprehensive test suite (18 tests)
  - [ ] UI integration (sidebar, dialogs, filtering) - *Next phase*
- [ ] Bulk operations (edit, delete, move)

---

## Mid-term (v0.3.x - Polish & Integration)

### User Experience
- [x] Refined dark/light theme with accent colors
- [x] Basic keyboard shortcuts (Ctrl+Q, Ctrl+Z, Ctrl+Shift+Z, Ctrl+comma) - **v0.2.7-beta**
- [x] Keyboard shortcuts help dialog (Ctrl+?) - **v0.2.7-beta**
- [ ] First-run wizard with security best practices
- [ ] Vault templates (personal, business, family)
- [ ] Trash/recycle bin for deleted accounts
- [ ] Account duplication feature
- [ ] Recently accessed accounts list
- [ ] Account usage statistics

### Distribution & Packaging
- [ ] Flatpak packaging for Flathub
- [x] AppImage distribution
- [ ] Snap package
- [ ] AUR package for Arch Linux
- [ ] RPM packaging improvements
- [ ] Debian/Ubuntu PPA

### Cross-platform Considerations
- [ ] Evaluate Windows port feasibility
- [ ] Evaluate macOS port feasibility
- [ ] Abstract platform-specific code

---

## Long-term (v0.4.x+ - Advanced Features)

### Cloud & Synchronization
- [ ] Optional cloud sync support
- [ ] Self-hosted sync server implementation
- [ ] Conflict resolution UI with merge strategies
- [ ] Offline-first architecture with sync reconciliation
- [ ] End-to-end encrypted sync protocol
- [ ] Delta sync for bandwidth efficiency
- [ ] Sync history and rollback

### Collaboration Features
- [ ] Shared vaults (family/team use cases)
- [ ] Permission levels (read-only, edit, admin)
- [ ] Audit logs for shared vaults
- [ ] Activity notifications
- [ ] Access revocation system

### Advanced Security
- [x] Hardware security key support (YubiKey challenge-response) - **v0.2.0+**
- [ ] FIDO2/WebAuthn support for vault unlock
- [ ] Secure password sharing (time-limited, one-time access)
- [ ] Breach monitoring integration (HaveIBeenPwned API)
- [ ] Security reports (weak passwords, reused passwords, old passwords)
- [ ] Password expiration policies
- [ ] Emergency access system
- [ ] Vault integrity monitoring

### Browser Integration (Post-v1.0.0)
- [ ] Browser extension for auto-fill (Firefox, Chrome)
- [ ] Native messaging host implementation
- [ ] Cross-browser compatibility layer
- [ ] Browser store distribution

### Enterprise Features
- [ ] LDAP/Active Directory integration
- [ ] SSO support
- [ ] Centralized policy management
- [ ] Compliance reporting (audit trails)
- [ ] Vault access monitoring dashboard

---

## Technical Debt & Quality (Ongoing)

### Throughout All Versions
- [ ] Maintain >80% test coverage for all new features
- [ ] Performance optimization for vaults with 1000+ accounts
- [ ] Memory usage profiling and optimization
- [ ] Accessibility improvements (WCAG 2.1 Level AA)
- [ ] Full screen reader support
- [ ] Comprehensive keyboard navigation
- [ ] Internationalization (i18n) framework
- [ ] Translations (Spanish, French, German, Japanese, Chinese)
- [x] Complete API documentation (Doxygen)
- [ ] User manual and help system
- [ ] Video tutorials and screencasts
- [ ] Developer documentation for contributors

### Code Quality
- [ ] Static analysis integration (clang-tidy, cppcheck)
- [ ] Continuous fuzzing setup (OSS-Fuzz)
- [ ] Code coverage tracking (Codecov)
- [ ] Performance benchmarking suite
- [ ] Automated security scanning (CodeQL)

---

## Quick Wins (Potential Next Sprint)

These features provide high value with relatively low implementation effort:

1. ✅ **Password strength indicator** - Visual feedback during password creation (Completed)
2. **Recently used accounts** - Quick access list on main window
3. ✅ **Basic keyboard shortcuts** - Ctrl+Q, Ctrl+Z, Ctrl+Shift+Z implemented (v0.2.7-beta)
4. **Account notes field** - Store security questions, recovery info
5. **Auto-backup verification** - Test restore integrity on backup creation
6. ✅ **Show/hide password toggle** - Eye icon in password fields (Completed)
7. **Password generation in account dialog** - One-click generation
8. **Account creation timestamp** - Display "Created" date
9. **Vault statistics** - Account count, last modified, file size
10. **Export single account** - Share one account securely

---

## Community & Project Management

### Short-term
- [ ] Contributing guidelines (CONTRIBUTING.md)
- [ ] Code of conduct
- [ ] Issue templates (bug report, feature request)
- [ ] Pull request template
- [ ] Roadmap voting/feedback system

### Medium-term
- [ ] Project website
- [ ] Community forum or Discord server
- [ ] Regular release schedule (monthly/quarterly)
- [ ] Release notes automation
- [ ] Beta testing program

### Long-term
- [ ] Foundation or sponsorship structure
- [ ] Commercial support options
- [ ] Plugin/extension API for third-party developers
- [ ] Public roadmap with community input

---

## Version Numbering Scheme

- **v0.x.x** - Pre-1.0 development releases (current phase)
- **v1.0.0** - First stable release (feature complete for core use cases)
- **v1.x.x** - Stable releases with incremental features
- **v2.0.0+** - Major architectural changes or paradigm shifts

---

## Contributing to the Roadmap

This roadmap is a living document. If you have suggestions, please:
1. Open an issue on GitHub with the `roadmap` label
2. Discuss in community channels
3. Submit a pull request with proposed changes to this document

**Last Updated:** December 14, 2025
**Current Status:** Active development, beta phase
